import React from 'react'
import LuckyWheel from './components/LuckyWheel'
import './App.css'

function App() {
  return (
    <div className="App">
      <LuckyWheel />
    </div>
  )
}

export default App