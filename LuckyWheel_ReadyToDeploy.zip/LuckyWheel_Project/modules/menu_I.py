async def menu_I_handler(client, callback):
    await callback.answer("⚡ MENU I sedang dalam pengembangan!", show_alert=True)
