async def menu_G_handler(client, callback):
    await callback.answer("⚡ MENU G sedang dalam pengembangan!", show_alert=True)
