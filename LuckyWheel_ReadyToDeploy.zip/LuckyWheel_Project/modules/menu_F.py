async def menu_F_handler(client, callback):
    await callback.answer("⚡ MENU F sedang dalam pengembangan!", show_alert=True)
