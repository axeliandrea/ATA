async def menu_E_handler(client, callback):
    await callback.answer("⚡ MENU E sedang dalam pengembangan!", show_alert=True)
